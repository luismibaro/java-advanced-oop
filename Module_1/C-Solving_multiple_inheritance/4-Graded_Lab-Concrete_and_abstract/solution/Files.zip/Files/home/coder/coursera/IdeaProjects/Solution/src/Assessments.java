interface Assessments {
void assignmentScore(int marks);
void quizScore(int marks);
}
