class OnlineCourse extends Course  {
    OnlineCourse(Subject subject, String instructor, int fee) {
        super(subject, instructor, fee);
    }
}
